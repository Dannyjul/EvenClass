<?php

    if (!empty($userId)) 
    {
        $notif = $crud->eksekusiSQL("SELECT *FROM transaksi WHERE 
        id_user='$userId' AND baca_member='Belum dibaca' ORDER BY id_transaksi DESC");

        $hitungNotif = $crud->hitungData($notif);
    }

?>