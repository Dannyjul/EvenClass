<?php


    if (!empty($iduser)) 
    {
        $tampil = $crud->tampilId("user", "email", "$iduser");

        foreach ($tampil as $key) 
        {
            $namauser = $key['nama_user'];
            $alamat   = $key['alamat'];
            $nohp     = $key['no_hp'];
            $email    = $key['email'];
            $passw    = $key['password'];
            $foto     = $key['foto'];
            $userId   = $key['id_user'];

            if ($foto=='Kosong') 
            {
                $gambar = "./img/nofoto.png";
                $acakGambar = md5($gambar);

            }
            else
            {
                $gambar ="./foto/$foto";
            }
        }
    }

?>