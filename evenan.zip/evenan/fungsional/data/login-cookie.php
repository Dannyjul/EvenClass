<?php

   //setcookie("userId", "");

    


    if (!empty($iduser)) 
    {
        include "./fungsional/halm/homeUser.php";

    }
    else
    {
       
        
        include "./fungsional/halm/homeUmum.php";
    }

?>