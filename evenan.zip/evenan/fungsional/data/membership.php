<a data-fancybox="gallery" href="<?php echo $gambar;?>" data-caption="<?php echo"$namauser";?>">
                  <img src="<?php echo $gambar;?>" width="100%" height="135" class="rounded-circle" alt="<?php echo"$namauser";?>">
                </a>
                
                <br>
                <div style="margin: 10px;">
                  <ul class="nav flex-column">
                    <li class="nav-item">
                      <a class="nav-link active" href="?hal=akun-dashboard">Dashboard</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="?hal=akun-membership">Membership</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="?hal=akun-transaksi">
                          Transaksi 
                          <sup><?php notifikasi($hitungNotif) ?></sup>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="#">Edit Account</a>
                    </li>
                  </ul>
                </div>