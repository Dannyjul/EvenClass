<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-danny fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">Evenan</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                    <a class="nav-link" href="?hal=event">Event</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?hal=course">Course</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Forum</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Community</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?hal=akun&mode=data">
                        Akun <img src="<?php echo $gambar; ?>" style="margin-left: 5px;" width="30" height="30" class="rounded-circle">
                        <sup><?php notifikasi($hitungNotif) ?></sup>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>


<div class="pesan">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis quasi laboriosam quam sit quis excepturi, aliquam doloremque repudiandae sunt ipsam consectetur ipsa! Veritatis, deserunt culpa repellendus qui veniam nihil numquam!</p>
</div>

