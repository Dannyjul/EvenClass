<?php
    include './fungsional/konfig/header.php';


    $id = $_GET['k'];
    
    $y = $crud->tampilId("event", "id_event", $id);

    foreach ($y as $a) 
    {
        $nama = $a['nama_event'];
        $foto = $a['foto_event'];
        $tgl  = $a['tanggal_post'];
        //$autor= $a['nama_user'];
        $desk = $a['deskripsi'];
        //$idev = $a['id_event'];

        $lokasinya = $a['lokasi'];
        $vanue = $a['venue'];
        $waktu = $a['waktu'];
        $kuota = $a['kuota'];
        $harga = $a['harga_event'];


        $biaya= "Rp ".formatRupiah($harga).",-";

        if ($foto=="Kosong") 
        {
            $gambar = "<img src='../img/nofoto.png' width='200' height='150'>";
        } 
        else 
        {
            $tujuan = "./foto/$foto";
            $gambar = 
            "   <a class='img-fluid' data-fancybox='$nama' href='$tujuan' data-caption='$nama'>
                    <img src='$tujuan' width='200' height='150'>
                </a>
            ";
        }

        $fotoEnkripsi = base64_decode($foto);
    }

?>

 

  <section>
    <div class="container" style="margin-top: 70px;">
    <h2 class="display-4" style="padding: 40px; padding-bottom:0px; text-align:center;">
      <?php echo $nama; ?>
    </h2>
      <div class="row">
        <div class="col-lg-6">
          <div class="p-5">
            <img class="img-fluid" src="<?php echo $tujuan; ?>" alt="">
          </div>
        </div>
          <div class="col-lg-6">
        
            <!--<h4 class="display-4">Nama Event</h4>-->

            <?php echo $desk; ?>

          </div>
        </div>
      </div>
    </div>

    <div class="container" style="margin: 80px auto; padding: 20px; background-color: gainsboro; width:50%;">
      <table width="40%" align="center" border="0">
        <tr>
          <td width="25%">Lokasi :</td>
          <td width="70%"><?php echo $lokasinya; ?></td>
        </tr>
        <tr>
          <td width="25%">Vanue :</td>
          <td width="70%"><?php echo $vanue; ?></td>
        </tr>
        <tr>
          <td width="25%">Waktu Pelaksanaan :</td>
          <td width="70%"><?php echo $waktu; ?></td>
        </tr>
        <tr>
          <td width="25%">Kuota Peserta :</td>
          <td width="70%"><?php echo $kuota; ?> Orang</td>
        </tr>
        <tr>
          <td width="25%">Biaya :</td>
          <td width="70%">
            <h3><?php echo $biaya; ?></h3>
          </td>
        </tr>
      </table>

      <center>

        <?php
          $isiTrans = $crud->eksekusiSQL("SELECT *FROM transaksi WHERE id_event='$id'");
          $cekHitung= $crud->hitungData($isiTrans);

          if ($cekHitung==2) 
          {
            $arahin=
            "
              <h2>Maaf, Kuota sudah Penuh</h2>
            ";
          } 
          else 
          {
            $arahin=
            "
            <a href='?hal=konfirmasi-pembayaran&k=$id&mau=event' class='btn btn-primary btn-lg'>
              DAFTAR EVENT
            </a>
            ";
          }
          

          echo "<p>$arahin</p>";
        ?>
      
      </center>
    </div>
  </section>

  
 

<?php
    include './fungsional/konfig/footer.php';
?>