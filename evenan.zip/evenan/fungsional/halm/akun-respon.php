<?php

    $mau = $_GET['mode'];

    if ($mau=='edit') 
    {
        $nama   = $_POST['nama'];
        $alamat = $_POST['alamat'];
        $nohp   = $_POST['nohp'];
        $email  = $_POST['email'];
        $pass   = $_POST['password'];

        $namafoto= $_FILES['foto']['name'];
        $lokfoto = $_FILES['foto']['tmp_name'];


        if (empty($foto)) 
        {
            $link = "nama_user = '$nama', alamat = '$alamat', 
                 no_hp='$nohp', email='$email', password='$pass'";
        }
        else
        {
            $nmaFoto = uploadFoto($namafoto, $lokfoto);

            //$tujuan  = "./foto/$foto";

            //move_uploaded_file($lokfoto, $tujuan);

            $target = "./foto/$foto";

            unlink($target);

            
            //move_uploaded_file($lokfoto, '../foto/'.$foto);
            $link = "nama_user = '$nama', alamat = '$alamat', 
                 no_hp='$nohp', email='$email', password='$pass', foto='$nmaFoto'";
        }

        $tabel= "user";
        

        $ubah = $crud->ubahData($tabel, $link, "id_user", $userId);
        $cek  = $crud->cekQuery($ubah);

        if ($cek==1) 
        {
            //echo "$lokfoto kkk";
            pindahHalaman("akun&mode=data");
        } 
        else 
        {
            pesanALert("Tidak bisa diubah");
            pindahHalaman("akun&mode=data");
        }
        
    }

?>