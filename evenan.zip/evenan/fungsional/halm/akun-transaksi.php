<?php
    include './fungsional/konfig/headerUdahLogin.php';
?>
<!--
  <header class="masthead gambar-bgUser" style="margin-top:0px;">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h1>Selamat Datang</h1>
          <p>
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Facere repellendus excepturi, placeat molestias molestiae rem iusto odio magni at sapiente voluptatum dolorum illum, optio qui minus aliquam repudiandae earum autem!
          </p>
        </div>

        <div class="col-md-6">
          <img src="./img/laptop.png" alt="Yeah" width="100%">
        </div>
      </div>
    </div>
  </header>
-->

  <section class="lapak-putih" style="margin-top: 0;">
    
    <div class="container lapak-putih" style="padding: 20px; margin-top:100px;">
        
        <div class="row">
            <div class="col-md-2">

               <?php
                include './fungsional/data/membership.php';
               ?>
            </div>

            <div class="col-md-10">
                <h1 style="margin: 30px; margin-bottom:0px;"><?php echo"$namauser";?></h1>
                <a style="margin-left: 30px;" href="?hal=logout" class="btn btn-primary">Logout</a>
                <hr>

                <div style="margin: 30px;">
                  <h3>Data Transaksi</h3>
                  <table class="table table-bordered table hover">
                      <thead>
                          <tr class="bg-primary text-white">
                            <th>No.</th>
                            <th>Nama Transaksi</th>
                            <th>Biaya Transaksi</th>
                            <th>No. Rekening</th>
                            <th>Pemilik Rekening</th>
                            <th>Tanggal Transaksi</th>
                            <th>Keterangan</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php

                          
                            $ubahan = "baca_member='Sudah dibaca'";

                            $ubahNotif = $crud->ubahData("transaksi", $ubahan, "id_user", $userId);


                            $sql   = "SELECT *FROM 
                                        transaksi
                                        WHERE id_user='$userId'
                                        ORDER BY id_transaksi DESC
                                     ";
                            $trans = $crud->eksekusiSQL($sql);
                            $hitung= $crud->hitungData($trans);

                            if ($hitung==0) 
                            {
                                echo
                                "
                                    <tr>
                                        <td colspan='7' align='center'>
                                            Belum ada Transaksi
                                        </td>  
                                    </tr>
                                ";
                            } 
                            else 
                            {
                                $no=1;
                                foreach ($trans as $key) 
                                {
                                    $namatrans = $key['nama_transaksi'];
                                    $harga     = $key['biaya_transaksi'];
                                    $norek     = $key['no_rek'];
                                    $narek     = $key['nama_rekening'];
                                    $tgl       = $key['tgl_transaksi'];

                                    $ket       = $key['keterangan'];

                                    if ($ket=="Ok") 
                                    {
                                        $isiKet="<span class='badge badge-success'>$ket</span>";
                                    } 
                                    elseif($ket=='Sedang diproses')
                                    {
                                        $isiKet="<span class='badge badge-warning'>$ket</span>";
                                    }
                                    else
                                    {
                                        $isiKet="<span class='badge badge-danger'>$ket</span>";
                                    }
                                    

                                    $tanggal   = date("d F Y, h:i", strtotime($tgl));

                                    $biaya = "Rp ".formatRupiah($harga).",-";
                                    
                                    echo
                                    "
                                        <tr>
                                            <td align='center'>$no</td>
                                            <td>$namatrans</td>
                                            <td>$biaya</td>
                                            <td>
                                                <center>
                                                    
                                                    $norek
                                                    
                                                </center>
                                            </td>
                                            <td>$narek</td>
                                            <td>$tanggal</td>
                                            <td>
                                                <center>
                                                    $isiKet
                                                </center>
                                            </td>
                                        </tr>
                                    ";
                                    $no++;
                                }
                            }
                            

                          ?>
                          
                      </tbody>
                  </table>
                </div>

            </div>
        </div>
   
    </div>

  </section>

  <!-- Modal -->
  <div class="modal fade" id="editUp" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Edit Profil</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <div class="modal-body">

                  <form method="post" action="?hal=akun-respon&mode=edit" enctype="multipart/form-data">
                      <p>
                          <input value="<?php echo $namauser; ?>" class="form-control" type="text" name="nama" placeholder="Nama Lengkap" required>
                      </p>
                      <p>
                          <textarea id="my-textarea" class="form-control" name="alamat" placeholder="Alamat" rows="3"><?php echo $alamat; ?></textarea>
                      </p>
                      <p>
                          <input value="<?php echo $nohp; ?>" class="form-control" type="number" name="nohp" placeholder="No. Handphone" required>
                      </p>
                      <p>
                          <input value="<?php echo $email; ?>" class="form-control" type="email" name="email" placeholder="E-Mail" required>
                      </p>
                      <p>
                          <input value="<?php echo $passw; ?>" class="form-control" type="password" name="password" placeholder="Password" required>
                      </p>
                      <p>
                          <input class="form-control" type="file" name="foto" placeholder="Password">
                      </p>
                      <p>
                          <input type="submit" value="SIMPAN" class="btn btn-primary">
                      </p>
                  </form>

              </div>

          </div>
      </div>
  </div>

 

<?php
    include './fungsional/konfig/footer.php';
?>