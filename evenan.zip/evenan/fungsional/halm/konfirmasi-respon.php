<?php

    $id = $_POST['k'];
    $mau= $_POST['mau'];

    $norek = $_POST['norek'];
    $nama  = $_POST['nama'];
    $harga = $_POST['harga'];
    $trans = $_POST['transaksi'];

    $waktu = date('Y-m-d h:i:s');

    if ($mau=='paket') 
    {
        $isi = "NULL,'$trans', '$norek', '$nama', '$waktu', '$id', NULL, '$userId', '$harga', 'Sedang diproses', 'Belum dibaca', 'Belum dibaca'";
        $simpan = $crud->tambahData("transaksi", $isi);
    }
    else
    {
        $isi = "NULL, '$trans', '$norek', '$nama', '$waktu', NULL, '$id', '$userId', '$harga', 'Sedang diproses', 'Belum dibaca', 'Belum dibaca'"; 
        $simpan = $crud->tambahData("transaksi", $isi);
    }

    $cekLagi = $crud->cekQuery($simpan);

    if ($cekLagi==1) 
    {
        pesanALert("Transaksi Anda sedang diproses");
        pindahHalaman("akun-transaksi");
    } 
    else 
    {
        pesanALert("Gagal");
        echo
        "
            $norek $nama $waktu, $id, $harga <br>
            $isi
        ";
    }
    

?>