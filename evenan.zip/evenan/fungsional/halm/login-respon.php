<?php

    $email    = $_POST['email'];
    $passw    = $_POST['password'];

    $eksekusi = $crud->loginData("user", "email", "password", $email, $passw);
    
    //$cekLogin = $crud->cekQuery($eksekusi);

    if ($eksekusi==1) 
    {
        setcookie("userEmail", "$email");
        pesanAlert("Berhasil");
        echo
        "
            <script>
                window.location='index.php';
            </script>
        ";
    }
    else
    {
        pesanAlert("Gagal");
        
        echo
        "
            <script>
                //window.location='index.php';
            </script>
        ";
    }

?>