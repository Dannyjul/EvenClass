-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 27, 2020 at 03:23 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evenan`
--

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id_event` int(11) NOT NULL,
  `nama_event` varchar(50) NOT NULL,
  `tanggal_post` date NOT NULL,
  `deskripsi` text NOT NULL,
  `foto_event` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `lokasi` text NOT NULL,
  `venue` varchar(50) NOT NULL,
  `waktu` datetime NOT NULL,
  `harga_event` double NOT NULL,
  `kuota` int(11) NOT NULL,
  `keterangan` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id_event`, `nama_event`, `tanggal_post`, `deskripsi`, `foto_event`, `id_user`, `lokasi`, `venue`, `waktu`, `harga_event`, `kuota`, `keterangan`) VALUES
(7, 'Event 1', '2020-10-25', '<p>Lorem ipsum&nbsp;is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.&nbsp;Lorem ipsum&nbsp;is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.</p>\r\n', 'Event-20201025070619.jpg', 11, 'Gor Cikutra', 'Jl. Cikutra', '2020-10-28 13:05:00', 350000, 3, 'POSTING'),
(8, 'Event 2', '2020-10-25', '<p>Lorem ipsum&nbsp;is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.&nbsp;Lorem ipsum&nbsp;is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.</p>\r\n', 'Event-20201025071132.jpg', 11, 'Aula Kampus', 'Jl. Cikutra', '2020-10-28 13:09:00', 100000, 2, 'POSTING'),
(9, 'Event 3', '2020-10-25', '<p>Lorem ipsum&nbsp;is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.&nbsp;Lorem ipsum&nbsp;is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.</p>\r\n', 'Event-20201025081708.jpg', 11, 'Aula Kampus ARS', 'Jl. Sulaksana No. 6', '2020-10-29 14:16:00', 100000, 2, 'POSTING');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `nama_kelas` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `foto_kelas` varchar(100) NOT NULL,
  `kondisi` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nama_kelas`, `deskripsi`, `foto_kelas`, `kondisi`) VALUES
(3, 'KELAS 1', '<p>akakjajja hahAK ahhakakhkhak ahkhAKha ahkahk.&nbsp;akakjajja hahAK ahhakakhkhak ahkhAKha ahkahk.&nbsp;akakjajja hahAK ahhakakhkhak ahkhAKha ahkahk.&nbsp;akakjajja hahAK ahhakakhkhak ahkhAKha ahkahk.&nbsp;akakjajja hahAK ahhakakhkhak ahkhAKha ahkahk.&nbsp;akakjajja hahAK ahhakakhkhak ahkhAKha ahkahk.</p>\r\n\r\n', 'Kelas-20201002052213.jpg', 'POSTING'),
(4, 'KELAS 2', '<p>asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.&nbsp;asajskajs sakskajska sakjska.</p>\r\n', 'Kelas-20201002052337.jpg', 'POSTING'),
(5, 'Kelas 3', '<p>sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;&nbsp;sanskaksjka saksak.&nbsp;</p>\r\n\r\n<p>sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;sanskaksjka saksak.&nbsp;&nbsp;sanskaksjka saksak.&nbsp;</p>\r\n', 'Kelas-20201014014908.jpg', 'POSTING'),
(6, 'KELAS 4', '<p>sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'Kelas-20201024014924.jpg', 'POSTING'),
(7, 'KELAS 5', '<p>sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.sajsakjksa sakshjkajska skhjahska.&nbsp;sajsakjksa sakshjkajska skhjahska.</p>\r\n', 'Kelas-20201024015017.jpg', 'POSTING');

-- --------------------------------------------------------

--
-- Table structure for table `kursus`
--

CREATE TABLE `kursus` (
  `id_kursus` int(11) NOT NULL,
  `nama_kursus` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `link_video` varchar(50) NOT NULL,
  `id_kelas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kursus`
--

INSERT INTO `kursus` (`id_kursus`, `nama_kursus`, `deskripsi`, `link_video`, `id_kelas`) VALUES
(7, 'Dasar Bisnis', '<p>hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.</p>\r\n\r\n<p>hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.</p>\r\n\r\n<p>hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.&nbsp;hskahsah shakhskahs sakhskahksha hsakhksahksa.</p>\r\n', 'https://www.youtube.com/watch?v=7AjYvpo2Fig', 3),
(9, 'Tujuan Bisnis', '<p>sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.</p>\r\n\r\n<p>sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.</p>\r\n\r\n<p>sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.&nbsp;sahkhsa hsakhsa shakhsa shakhskah.</p>\r\n', 'https://www.youtube.com/watch?v=Jom68Ue3YfQ', 3),
(10, 'Motivasi Berbisnis', '<p>alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.</p>\r\n\r\n<p>alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.</p>\r\n\r\n<p>alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.&nbsp;alsakhska sahksha skahksha sakhshka sakhskah hskahska sahkhska.</p>\r\n', 'https://www.youtube.com/watch?v=t4U3ZP8ekDo', 3),
(11, 'Tipe Pebisnis', '<p>ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.ajksjakshka skahksha.ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.ajksjakshka skahksha.ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.ajksjakshka skahksha.</p>\r\n\r\n<p>ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.ajksjakshka skahksha.ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.ajksjakshka skahksha.ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.&nbsp;ajksjakshka skahksha.ajksjakshka skahksha.</p>\r\n', 'https://www.youtube.com/watch?v=5zMNkUkRxSQ', 4);

-- --------------------------------------------------------

--
-- Table structure for table `paket_member`
--

CREATE TABLE `paket_member` (
  `id_paket` int(11) NOT NULL,
  `nama_paket` varchar(50) NOT NULL,
  `harga_member` double NOT NULL,
  `deskripsi_paket` text NOT NULL,
  `kondisi` varchar(10) NOT NULL,
  `jumlah_kelas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paket_member`
--

INSERT INTO `paket_member` (`id_paket`, `nama_paket`, `harga_member`, `deskripsi_paket`, `kondisi`, `jumlah_kelas`) VALUES
(1, 'Free User', 0, '<p>saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.&nbsp;saksah sjakjsa.</p>\r\n', 'POSTING', 1),
(2, 'Self Employee', 2000000, '<p>hskahsa shakhsa shaksah hksahsa.&nbsp;hskahsa shakhsa shaksah hksahsa.&nbsp;hskahsa shakhsa shaksah hksahsa.&nbsp;hskahsa shakhsa shaksah hksahsa.</p>\r\n\r\n<p>hskahsa shakhsa shaksah hksahsa.&nbsp;hskahsa shakhsa shaksah hksahsa.&nbsp;hskahsa shakhsa shaksah hksahsa.&nbsp;hskahsa shakhsa shaksah hksahsa.</p>\r\n', 'POSTING', 3),
(3, 'Enterpreneur', 4000000, '<p>zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.</p>\r\n\r\n<p>zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.&nbsp;zxkzxz.</p>\r\n', 'POSTING', 6);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `nama_transaksi` varchar(50) NOT NULL,
  `no_rek` varchar(50) NOT NULL,
  `nama_rekening` varchar(50) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `id_paket` int(11) DEFAULT NULL,
  `id_event` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `biaya_transaksi` double NOT NULL,
  `keterangan` varchar(25) NOT NULL,
  `baca_admin` varchar(20) NOT NULL,
  `baca_member` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `nama_transaksi`, `no_rek`, `nama_rekening`, `tgl_transaksi`, `id_paket`, `id_event`, `id_user`, `biaya_transaksi`, `keterangan`, `baca_admin`, `baca_member`) VALUES
(4, 'Upgrade Membership ke-Self Employee', '1234567', 'Budi Budian', '2020-10-25 02:37:30', 2, NULL, 17, 2000000, 'Ok', 'Belum dibaca', 'Belum dibaca'),
(5, 'Upgrade Membership ke-Enterpreneur', '12345678', 'Aristyo Budiman', '2020-10-25 04:21:25', 3, NULL, 17, 4000000, 'Ok', 'Belum dibaca', 'Belum dibaca'),
(6, 'Upgrade Membership ke-Self Employee', '901212121', 'Danny Jul', '2020-10-25 04:23:51', 2, NULL, 16, 2000000, 'Ok', 'Belum dibaca', 'Sudah dibaca'),
(7, 'Mengikuti Event Event 3', '90121212121', 'Madabi', '2020-10-25 08:38:38', NULL, 9, 16, 100000, 'Ok', 'Belum dibaca', 'Sudah dibaca'),
(8, 'Mengikuti Event Event 3', '123333434', 'Bella Wardini', '2020-10-25 09:45:22', NULL, 9, 18, 100000, 'Ok', 'Belum dibaca', 'Sudah dibaca'),
(9, 'Upgrade Membership ke-Self Employee', '1213223', 'Salsabila', '2020-10-27 03:08:39', 2, NULL, 20, 2000000, 'Ok', 'Belum dibaca', 'Sudah dibaca'),
(10, 'Upgrade Membership ke-Enterpreneur', '121212121', 'sasasasa', '2020-10-27 03:11:59', 3, NULL, 20, 4000000, 'Ok', 'Belum dibaca', 'Sudah dibaca'),
(11, 'Mengikuti Event Event 2', '121212121', 'Danny Julian', '2020-10-27 03:13:31', NULL, 8, 20, 100000, 'Ok', 'Belum dibaca', 'Sudah dibaca'),
(12, 'Mengikuti Event Event 2', '112112121', 'Danny Julian', '2020-10-27 03:14:49', NULL, 8, 16, 100000, 'Ok', 'Belum dibaca', 'Sudah dibaca');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `hak_akses` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `alamat`, `no_hp`, `email`, `password`, `foto`, `hak_akses`) VALUES
(11, 'Admin', 'Antapanai', '08989898989', 'evenan@mail.com', '123456', 'Kosong', 'Administrator'),
(16, 'Danny Julian', 'Cikutra', '089898988999', 'julianpratamad@gmail.com', '123456', 'Foto-20201024113822.jpg', 'Member'),
(17, 'Aristyo', 'Picung', '08798989898', 'aridto@gmail.com', '123456', 'Foto-20201024013930.jpg', 'Member'),
(18, 'Bella Wardini', 'Jl. Margacinta', '089898212121', 'bellawar@gmail.com', '123456', 'Foto-20201025094400.jpg', 'Member'),
(19, 'Erni Sulistiawati', 'Jl. Buah Batu', '0899892121', 'ernisti@gmail.com', '123456', 'Kosong', 'Member'),
(20, 'Salsabila', 'Sulaksana', '0898992121121', 'salsa@gmail.com', '123456', 'Kosong', 'Member');

-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE `user_status` (
  `id_userstats` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_paket` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`id_userstats`, `id_user`, `id_paket`) VALUES
(1, 16, 2),
(2, 17, 3),
(3, 18, 1),
(4, 19, 1),
(5, 20, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id_event`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `kursus`
--
ALTER TABLE `kursus`
  ADD PRIMARY KEY (`id_kursus`),
  ADD KEY `id_kelas` (`id_kelas`);

--
-- Indexes for table `paket_member`
--
ALTER TABLE `paket_member`
  ADD PRIMARY KEY (`id_paket`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_paket` (`id_paket`),
  ADD KEY `id_event` (`id_event`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_user_2` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `user_status`
--
ALTER TABLE `user_status`
  ADD PRIMARY KEY (`id_userstats`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_paket` (`id_paket`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kursus`
--
ALTER TABLE `kursus`
  MODIFY `id_kursus` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `paket_member`
--
ALTER TABLE `paket_member`
  MODIFY `id_paket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user_status`
--
ALTER TABLE `user_status`
  MODIFY `id_userstats` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `event_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kursus`
--
ALTER TABLE `kursus`
  ADD CONSTRAINT `kursus_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `event` FOREIGN KEY (`id_event`) REFERENCES `event` (`id_event`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `paket` FOREIGN KEY (`id_paket`) REFERENCES `paket_member` (`id_paket`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_status`
--
ALTER TABLE `user_status`
  ADD CONSTRAINT `paketan` FOREIGN KEY (`id_paket`) REFERENCES `paket_member` (`id_paket`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
