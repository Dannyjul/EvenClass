<?php

    $mau = @$_GET['mau'];
    
    if ($mau=='tambah') 
    {
        $nama = $_POST['nama'];
        $link = $_POST['link'];
        $desk = $_POST['deskripsi'];
        $idkel= $_POST['idkelas'];
        

        $isian     = "NULL, '$nama', '$desk', '$link', '$idkel'";
 
        

        $perintah = $isi->tambahData("kursus", $isian);
        $eksekusi = $isi->cekQuery($perintah);

        if ($eksekusi==1) 
        {
           pesanALert("Data tersimpan");
           pindahHal('?hal=kursus-data');
        } 
        else 
        {
            pesanALert("Gagal tersimpan");
            //pindahHal('?hal=event-tambah');
        }
        
    }
    elseif ($mau=="hapus") 
    {
        $ide = @$_GET['ide'];
        //$foto= $_GET['f'];

        //$tujuan = "../foto/$foto";

        $perintah = $isi->hapusData("kursus", "id_kursus", "$ide");

        $eksekusi = $isi->cekQuery($perintah);

        if ($eksekusi==1) 
        {
           //unlink($tujuan);
           pesanALert("Data terhapus");
           pindahHal('?hal=kursus-data');
        } 
        else 
        {
            pesanALert("Gagal terhapus");
            //pindahHal('?hal=event-tambah');
        }
    }
    else
    {
        $id   = $_POST['id'];
        $nama = $_POST['nama'];
        $desk = $_POST['deskripsi'];
        
        $simpan = $_POST['simpan'];

        $idUser = $userIdnya;

        $tgl    = date('Y-m-d');

        $fotonm = $_FILES['foto']['name'];
        $lokasi = $_FILES['foto']['tmp_name'];

        if (!empty($fotonm)) 
        {
            $k= $_GET['k'];
            $l= base64_encode($k);

            $tujuan = "../foto/$l";
            $newe = uploadFoto($fotonm, $lokasi);

            //$isian     = "NULL, '$nama', '$tgl', '$desk', '$newe', '$idUser'";
            $isian     = "nama_event='$nama', deskripsi='$desk', foto_event='$newe'";
        } 
        else 
        {
            //$isian     = "NULL, '$nama', '$tgl', '$desk', 'Kosong', '$idUser'";
            $isian = "nama_event='$nama', deskripsi='$desk'";
        }
        

        $perintah = $isi->ubahData("event", $isian, "id_event", $id);
        $eksekusi = $isi->cekQuery($perintah);

        if ($eksekusi==1) 
        {
           pesanALert("Data tersimpan");
           //pindahHal('?hal=event-data');
        } 
        else 
        {
            pesanALert("Gagal tersimpan");
            //pindahHal('?hal=event-tambah');
        }
    }



?>