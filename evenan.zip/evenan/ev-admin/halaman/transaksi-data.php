 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Transaksi</h1>
         <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
     </div>


     <!-- Content Row -->

     <div class="row">

         <!-- Area Chart -->
         <div class="col-xl-12">

             <div class="card shadow mb-4">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                     <h6 class="m-0 font-weight-bold text-primary">Semua Data</h6>
                 </div>

                 <div class="card-body">
                     
                    
                    <br><br>
                     <?php
                
                        $perintah = $isi->eksekusiSQl("SELECT *FROM 
                                                       transaksi
                                                       INNER JOIN user ON
                                                                transaksi.id_user = user.id_user
                                                       ORDER BY id_transaksi DESC
                                                       ");
                        $hitung   = $isi->hitungData($perintah);

                        if ($hitung==0) 
                        {
                            pesanKosong();
                        }
                        else
                        {
                           echo
                           "
                           <div class='table-responsive'>
                                <table class='table table-bordered' id='dataTable' width='100%' cellspacing='0' style='font-size:14px;'>
                                    <thead class='bg-gradient-primary text-white'>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama Transaksi</th>
                                            <th>Biaya Transaksi</th>
                                            <th>No. Rekening</th>
                                            <th>Pemilik Rekening</th>
                                            <th>Tanggal Transaksi</th>
                                            <th>Keterangan</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                            ";

                           // $tampilin = $isi->tampilData("user");

                           $no=1;
                           foreach ($perintah as $key) 
                           {
                               $namatrans = $key['nama_transaksi'];
                               $harga     = $key['biaya_transaksi'];
                               $norek     = $key['no_rek'];
                               $narek     = $key['nama_rekening'];
                               $tgl       = $key['tgl_transaksi'];
                               $iduser    = $key['id_user'];
                               $nmuser    = $key['nama_user'];
                               $foto      = $key['foto'];

                               $ket       = $key['keterangan'];

                               $idtrans   = $key['id_transaksi'];

                               if ($foto=='Kosong') 
                                {
                                    $gambar = "<img class='rounded-circle' src='../img/nofoto.png' width='50' height='50'>";
                                } 
                                else 
                                {
                                    $tujuan = "../foto/$foto";
                                    $gambar = 
                                    "   <a data-fancybox='gallery$nmuser' href='$tujuan' data-caption='$nmuser - $namatrans'>
                                            <img src='$tujuan' width='50' height='50'>
                                        </a>
                                    ";
                                }

                               if ($ket=="Ok") 
                               {
                                   $isiKet="<span class='badge badge-success'>$ket</span>";
                               } 
                               elseif($ket=='Sedang diproses')
                               {
                                   $isiKet="<span class='badge badge-warning'>$ket</span>";
                               }
                               else
                               {
                                   $isiKet="<span class='badge badge-danger'>$ket</span>";
                               }
                               

                               $tanggal   = date("d F Y, h:i", strtotime($tgl));

                               $biaya = "Rp ".formatRupiah($harga).",-";
                               
                               echo
                               "
                                   <tr>
                                       <td align='center'>$no</td>
                                       <td>
                                        $gambar <b>$nmuser</b> <br>
                                        $namatrans
                                       </td>
                                       <td>$biaya</td>
                                       <td>
                                           <center>
                                               
                                               $norek
                                               
                                           </center>
                                       </td>
                                       <td>$narek</td>
                                       <td>$tanggal</td>
                                       <td>
                                           <center>
                                               $isiKet
                                           </center>
                                       </td>
                                       <td>
                                            <center>
                                                <div class='btn-group' role='group'>
                                                    <button id='aksi' type='button' class='btn btn-secondary btn-sm dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                                                    Aksi
                                                    </button>
                                                    <div class='dropdown-menu' aria-labelledby='aksi'>
                                                        <a class='dropdown-item bg-success text-white' href='?hal=transaksi-respon&id=$idtrans&mau=ok'>Ok</a>
                                                        <a class='dropdown-item bg-danger text-white' href='?hal=transaksi-respon&id=$idtrans&mau=banned'>Banned</a>
                                                    </div>
                                                </div>
                                            </center>
                                       </td>
                                   </tr>
                               ";
                               $no++;
                           }
                            
                            

                            echo
                            "
                                    </tbody>
                                </table>
                            </div>
                           "; 
                        }

                    ?>
                 </div>
             </div>



         </div>


     </div>


 </div>
 <!-- /.container-fluid -->