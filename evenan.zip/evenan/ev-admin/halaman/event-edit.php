<?php

    $id = $_GET['ide'];
    
    $y = $isi->tampilId("event", "id_event", $id);

    foreach ($y as $a) 
    {
        $nama = $a['nama_event'];
        $foto = $a['foto_event'];
        $tgl  = $a['tanggal_post'];
        //$autor= $a['nama_user'];
        $desk = $a['deskripsi'];
        //$idev = $a['id_event'];

        if ($foto=="Kosong") 
        {
            $gambar = "<img src='../img/nofoto.png' width='200' height='150'>";
        } 
        else 
        {
            $tujuan = "../foto/$foto";
            $gambar = 
            "   <a data-fancybox='$nama' href='$tujuan' data-caption='$nama'>
                    <img src='$tujuan' width='200' height='150'>
                </a>
            ";
        }

        $fotoEnkripsi = base64_decode($foto);
    }

?>

<form action="?hal=event-respon&mau=edit&k=<?php echo $fotoEnkripsi; ?>" method="post" enctype="multipart/form-data">
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Event</h1>
            <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
        </div>


        <!-- Content Row -->

        <div class="row">

            <!-- Area Chart -->

            <div class="col-md-9">
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Edit Event</h6>
                    </div>


                    <div class="card-body">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">

                        <p>
                            <input value="<?php echo $nama; ?>" class="form-control" type="text" name="nama" placeholder="Judul Event" required>
                        </p>

                        <p>
                            <textarea name="deskripsi" class="ckeditor"><?php echo $desk; ?></textarea>
                        </p>



                    </div>
                </div>
            </div>

            <div class="col-md-3">

                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Opsi Simpan</h6>
                       
                    </div>


                    <div class="card-body">

                        <center>
                            <input type="submit" value="POSTING" class="btn btn-primary" name="simpan">
                            <input type="submit" value="DRAFT" class="btn btn-secondary">
                        </center>

                    </div>
                </div>

                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Gambar Event</h6>
                       
                    </div>


                    <div class="card-body">

                        <center>
                            <p>
                                <?php echo $gambar; ?>
                            </p>

                            <input type="file" name="foto" class="btn btn-primary">
                        </center>

                    </div>
                </div>

            </div>


        </div>
        <!-- /.container-fluid -->
</form>