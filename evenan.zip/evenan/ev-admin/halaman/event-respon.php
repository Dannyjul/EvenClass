<?php

    $mau = @$_GET['mau'];
    
    if ($mau=='tambah') 
    {
        $nama = $_POST['nama'];
        $desk = $_POST['deskripsi'];
        
        $simpan = $_POST['simpan'];

        $idUser = $userIdnya;

        $tempat = $_POST['lokasi'];
        $venue  = $_POST['vanue'];
        $waktu  = $_POST['waktu'];
        $harga  = $_POST['harga'];
        $kuota  = $_POST['kuota'];


        $tgl    = date('Y-m-d');

        $fotonm = $_FILES['foto']['name'];
        $lokasi = $_FILES['foto']['tmp_name'];


        if ($simpan=='POSTING') 
        {
            $postingan ='POSTING';
        } 
        else 
        {
            $postingan = 'DRAFT';
        }
        

        

        if (!empty($fotonm)) 
        {
            $newe = uploadFoto($fotonm, $lokasi);

            $isian     = "NULL, '$nama', '$tgl', '$desk', '$newe', '$idUser', '$tempat', '$venue','$waktu', '$harga', '$kuota', '$postingan'";
        } 
        else 
        {
            $isian     = "NULL, '$nama', '$tgl', '$desk', 'Kosong', '$idUser', '$tempat', '$venue','$waktu', '$harga', '$kuota', '$postingan'";
        }
        

        $perintah = $isi->tambahData("event", $isian);
        $eksekusi = $isi->cekQuery($perintah);

        if ($eksekusi==1) 
        {
           pesanALert("Data tersimpan");
           pindahHal('?hal=event-data');
        } 
        else 
        {
            pesanALert("Gagal tersimpan");
            //pindahHal('?hal=event-tambah');
        }
        
    }
    elseif ($mau=="hapus") 
    {
        $ide = @$_GET['ide'];
        $foto= $_GET['f'];

        $tujuan = "../foto/$foto";

        $perintah = $isi->hapusData("event", "id_event", "$ide");

        $eksekusi = $isi->cekQuery($perintah);

        if ($eksekusi==1) 
        {
           unlink($tujuan);
           pesanALert("Data terhapus");
           pindahHal('?hal=event-data');
        } 
        else 
        {
            pesanALert("Gagal terhapus");
            //pindahHal('?hal=event-tambah');
        }
    }
    else
    {
        $id   = $_POST['id'];
        $nama = $_POST['nama'];
        $desk = $_POST['deskripsi'];
        
        $simpan = $_POST['simpan'];

        $idUser = $userIdnya;

        $tgl    = date('Y-m-d');

        $fotonm = $_FILES['foto']['name'];
        $lokasi = $_FILES['foto']['tmp_name'];

        if (!empty($fotonm)) 
        {
            $k= $_GET['k'];
            $l= base64_encode($k);

            $tujuan = "../foto/$l";
            $newe = uploadFoto($fotonm, $lokasi);

            //$isian     = "NULL, '$nama', '$tgl', '$desk', '$newe', '$idUser'";
            $isian     = "nama_event='$nama', deskripsi='$desk', foto_event='$newe'";
        } 
        else 
        {
            //$isian     = "NULL, '$nama', '$tgl', '$desk', 'Kosong', '$idUser'";
            $isian = "nama_event='$nama', deskripsi='$desk'";
        }
        

        $perintah = $isi->ubahData("event", $isian, "id_event", $id);
        $eksekusi = $isi->cekQuery($perintah);

        if ($eksekusi==1) 
        {
           pesanALert("Data tersimpan");
           //pindahHal('?hal=event-data');
        } 
        else 
        {
            pesanALert("Gagal tersimpan");
            //pindahHal('?hal=event-tambah');
        }
    }



?>