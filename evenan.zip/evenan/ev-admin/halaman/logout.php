<?php

    //setcookie("userAkun", "$email");
    setcookie("userAkun", "");
    //pindahHal("index.php");

?>