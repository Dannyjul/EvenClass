 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Data Membership</h1>
         <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
     </div>


     <!-- Content Row -->

     <div class="row">

         <!-- Area Chart -->
         <div class="col-xl-12">

             <div class="card shadow mb-4">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                     <h6 class="m-0 font-weight-bold text-primary">Data Semua Member</h6>
                 </div>

                 <div class="card-body">
                    <a class='btn btn-primary' href='?hal=membership-tambah'>Tambah</a>

                     <?php
                
                        $perintah = $isi->eksekusiSQl("SELECT *FROM paket_member");
                        $hitung   = $isi->hitungData($perintah);

                        if ($hitung==0) 
                        {
                            pesanKosong();
                        }
                        else
                        {
                           echo
                           "
                           <div class='table-responsive'>
                                <table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
                                    <thead class='thead-dark'>
                                        <tr>
                                            <th>No.</th>
                                            <th>Membership</th>
                                            <th>Harga</th>
                                            <th>Kondisi</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                            ";

                            $tampilin = $isi->tampilData("paket_member");

                            $no=1;
                            foreach($tampilin as $a)
                            {
                                $nama   = $a['nama_status'];
                                $harga  = $a['harga_member'];
                                $kondisi= $a['kondisi'];
                               
                                if ($kondisi=='POSTING') 
                                {
                                    $tampilnya ="<span class='badge badge-primary'>$kondisi</span>";
                                } 
                                else 
                                {
                                    $tampilnya ="<span class='badge badge-secondary'>$kondisi</span>";
                                }
                                
                                
                 
                                
                                echo
                                "
                                    <tbody>
                                        <tr>
                                            <td align='center'>$no</td>
                                        
                                            <td>$nama</td>
                                            <td>$harga</td>
                                            <td>$tampilnya</td>
                                            
                                            
                                            <td>
                                                <center>
                                                    <a class='btn btn-warning' href='#'>Edit</a>
                                                    <a class='btn btn-danger' href='#'>Hapus</a>
                                                </center>
                                            </td>
                                        </tr>
                                ";
                                $no++;
                            }
                            
                            

                            echo
                            "
                                    </tbody>
                                </table>
                            </div>
                           "; 
                        }

                    ?>
                 </div>
             </div>



         </div>


     </div>


 </div>
 <!-- /.container-fluid -->