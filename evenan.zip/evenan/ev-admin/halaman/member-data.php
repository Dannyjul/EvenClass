 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Data Member</h1>
         <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
     </div>


     <!-- Content Row -->

     <div class="row">

         <!-- Area Chart -->
         <div class="col-xl-12">

             <div class="card shadow mb-4">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                     <h6 class="m-0 font-weight-bold text-primary">Data Semua Member</h6>
                 </div>

                 <div class="card-body">
                     

                     <?php
                
                        $perintah = $isi->eksekusiSQl("SELECT *FROM user");
                        $hitung   = $isi->hitungData($perintah);

                        if ($hitung==0) 
                        {
                            pesanKosong();
                        }
                        else
                        {
                           echo
                           "
                           <div class='table-responsive'>
                                <table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
                                    <thead class='thead-dark'>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama User</th>
                                            <th>Alamat</th>
                                            <th>E-Mail</th>
                                            <th>No. Handphone</th>
                                            <th>Hak Akses</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                            ";

                            $tampilin = $isi->tampilData("user");

                            $no=1;
                            foreach($tampilin as $a)
                            {
                                $nama   = $a['nama_user'];
                                $alamat = $a['alamat'];
                                $email  = $a['email'];
                                $nohp   = $a['no_hp'];
                                $foto   = $a['foto'];
                                $hak    = $a['hak_akses'];

                                if ($foto=='Kosong') 
                                {
                                    $gambar = "<img class='rounded-circle' src='../img/nofoto.png' width='50' height='50'>";
                                } 
                                else 
                                {
                                    $tujuan = "../foto/$foto";
                                    $gambar = 
                                    "   <a data-fancybox='gallery' href='$tujuan' data-caption='$nama'>
                                            <img class='rounded-circle' src='$tujuan' width='50' height='50'>
                                        </a>
                                    ";
                                }

                                
                 
                                
                                echo
                                "
                                    <tbody>
                                        <tr>
                                            <td align='center'>$no</td>
                                            <td>
                                                <center>
                                                    $gambar 
                                                    <br> <br>
                                                    <p>$nama</p>
                                                </center>
                                            </td>
                                            <td>$alamat</td>
                                            <td>$email</td>
                                            <td>$nohp</td>
                                            <td>$hak</td>
                                            
                                            <td>
                                                <center>
                                                    <a class='btn btn-warning' href='#'>Edit</a>
                                                    <a class='btn btn-danger' href='#'>Hapus</a>
                                                </center>
                                            </td>
                                        </tr>
                                ";
                                $no++;
                            }
                            
                            

                            echo
                            "
                                    </tbody>
                                </table>
                            </div>
                           "; 
                        }

                    ?>
                 </div>
             </div>



         </div>


     </div>


 </div>
 <!-- /.container-fluid -->