<?php

    


    if (!empty($admin)) 
    {
        $tampil = $isi->tampilId("user", "email", "$admin");

        foreach ($tampil as $key) 
        {
            $namauser = $key['nama_user'];
            $alamat   = $key['alamat'];
            $nohp     = $key['no_hp'];
            $email    = $key['email'];
            $passw    = $key['password'];
            $foto     = $key['foto'];
            $userIdnya= $key['id_user'];

            if ($foto=='Kosong') 
            {
                $gambar = "../img/nofoto.png";
                $acakGambar = md5($gambar);

            }
            else
            {
                $gambar ="../foto/$foto";
            }
        }
    }

?>