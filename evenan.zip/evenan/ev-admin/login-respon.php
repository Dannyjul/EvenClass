<?php

    //include '../fungsional/data/koneksi.php';
    include  './fungsi/konfigAdmin.php';
    include '../fungsional/data/isiData.php';

    include './fungsi/fungsian.php';

    $isi = new isiData();

    $email    = $_POST['email'];
    $passw    = $_POST['password'];

    $eksekusi = $isi->loginData("user", "email", "password", $email, $passw);
    
    //$cekLogin = $crud->cekQuery($eksekusi);

    if ($eksekusi==1) 
    {
        setcookie("userAkun", "$email");
        pesanAlert("Berhasil");
        echo
        "
            $email dan $passw
            <script>
                window.location='index.php';
            </script>
        ";
    }
    else
    {
        pesanAlert("Gagal");
        echo
        "$email dan $passw $eksekusi
            <script>
              window.location='index.php';
            </script>
        ";
    }

?>